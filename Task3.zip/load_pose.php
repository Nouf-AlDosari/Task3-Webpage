<?php
$conn = new mysqli("localhost", "root", "", "robot_arm");
$id = $_GET["id"];
$res = $conn->query("SELECT * FROM poses WHERE id=$id");
echo json_encode($res->fetch_assoc());
?>