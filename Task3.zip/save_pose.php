<?php
$conn = new mysqli("localhost", "root", "", "robot_arm");
$data = json_decode(file_get_contents("php://input"), true);
$motors = $data["motors"];
$stmt = $conn->prepare("INSERT INTO poses (motor1, motor2, motor3, motor4, motor5, motor6, status) VALUES (?, ?, ?, ?, ?, ?, 1)");
$stmt->bind_param("iiiiii", ...$motors);
$stmt->execute();
$conn->close();
?>